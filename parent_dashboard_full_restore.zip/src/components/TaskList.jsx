import { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  MenuItem,
  Button,
  List,
  ListItem,
  ListItemText,
  Divider,
} from "@mui/material";
import axios from "axios";

const TaskList = ({ tasks, patientId, editable }) => {
  const [task] = tasks;
  const [completed, setCompleted] = useState(task?.completed ?? false);
  const [reason, setReason] = useState(task?.reason_not_completed || "");
  const [reaction, setReaction] = useState(task?.allergy_reaction || "");
  const [notes, setNotes] = useState(task?.notes || "");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    try {
      setSaving(true);
      await axios.patch(`/api/tasks/${task.id}`, {
        completed,
        reason_not_completed: completed ? "" : reason,
        allergy_reaction: completed ? reaction : null,
        notes,
      });
      alert("🟢 עודכן בהצלחה");
    } catch (err) {
      console.error("❌ שגיאה בעדכון", err);
      alert("שגיאה בעדכון");
    } finally {
      setSaving(false);
    }
  };

  if (!tasks || tasks.length === 0) return null;

  return (
    <Box sx={{ mb: 3 }}>
      {editable && (
        <>
          <Typography variant="subtitle1" gutterBottom>
            📝 מענה למשימה: {task.description}
          </Typography>

          <TextField
            select
            label="האם בוצע?"
            value={completed ? "yes" : "no"}
            onChange={(e) => setCompleted(e.target.value === "yes")}
            fullWidth sx={{ mb: 2 }}
          >
            <MenuItem value="yes">כן</MenuItem>
            <MenuItem value="no">לא</MenuItem>
          </TextField>

          {!completed && (
            <TextField
              select
              label="סיבת אי-ביצוע"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              fullWidth sx={{ mb: 2 }}
            >
              <MenuItem value="שכחתי">שכחתי</MenuItem>
              <MenuItem value="מחלה">מחלה</MenuItem>
              <MenuItem value="מחסור במוצר">מחסור במוצר</MenuItem>
              <MenuItem value="אחר">אחר</MenuItem>
            </TextField>
          )}

          {completed && (
            <TextField
              select
              label="תגובה אלרגית (1–5)"
              value={reaction}
              onChange={(e) => setReaction(e.target.value)}
              fullWidth sx={{ mb: 2 }}
            >
              {[1, 2, 3, 4, 5].map((num) => (
                <MenuItem key={num} value={num}>{num}</MenuItem>
              ))}
            </TextField>
          )}

          <TextField
            label="הערות"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            fullWidth multiline rows={2} sx={{ mb: 2 }}
          />

          <Button variant="contained" onClick={handleSubmit} disabled={saving}>
            שלח משוב
          </Button>

          <Divider sx={{ my: 3 }} />
        </>
      )}

      {!editable && (
        <>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            📋 היסטוריית משימות
          </Typography>
          <List dense>
            {tasks.map((t) => (
              <ListItem key={t.id} divider>
                <ListItemText
                  primary={t.description}
                  secondary={`תאריך: ${t.date} | בוצע: ${t.completed ? "✅" : "❌"}`}
                />
              </ListItem>
            ))}
          </List>
        </>
      )}
    </Box>
  );
};

export default TaskList;
