import React, { useState } from 'react';
import {
  Card, CardContent, Typography, FormControl, InputLabel,
  Select, MenuItem, TextField, Button, Divider, Box
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AssignmentIcon from '@mui/icons-material/Assignment';
import { patchTask } from '../../utils/api';

const TaskList = ({ tasks, patient, refreshTasks }) => {
  const [formData, setFormData] = useState({});
  const today = new Date().toISOString().split('T')[0];
  const todayTask = tasks.find(t => t.date === today);
  const pastTasks = tasks.filter(t => t.date !== today);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (!todayTask) return;
    await patchTask(todayTask.id, formData);
    refreshTasks();
    // לא נסגור את הכרטיס - נחכה לאינטראקציה ידנית
  };

  return (
    <Box sx={{ mt: 2 }}>
      <Typography variant="h6" gutterBottom>
        {patient.name}
      </Typography>

      {todayTask && (
        <Card variant="outlined" sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="subtitle1" sx={{ mb: 2 }}>
              <AssignmentIcon fontSize="small" sx={{ mr: 1 }} />
              מענה למשימה: {todayTask.description} ({todayTask.date})
            </Typography>

            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>האם בוצע?</InputLabel>
              <Select
                value={formData.completed ?? ''}
                onChange={e => handleChange('completed', e.target.value === 'true')}
              >
                <MenuItem value="true">כן</MenuItem>
                <MenuItem value="false">לא</MenuItem>
              </Select>
            </FormControl>

            {formData.completed === false && (
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel>סיבת אי-ביצוע</InputLabel>
                <Select
                  value={formData.reason_not_completed ?? ''}
                  onChange={e => handleChange('reason_not_completed', e.target.value)}
                >
                  <MenuItem value="מחלה">מחלה</MenuItem>
                  <MenuItem value="שכחה">שכחה</MenuItem>
                  <MenuItem value="מחסור במוצר">מחסור במוצר</MenuItem>
                  <MenuItem value="אחר">אחר</MenuItem>
                </Select>
              </FormControl>
            )}

            {formData.completed === true && (
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel>דרגת תגובה אלרגית</InputLabel>
                <Select
                  value={formData.allergy_reaction ?? ''}
                  onChange={e => handleChange('allergy_reaction', e.target.value)}
                >
                  {[1, 2, 3, 4, 5].map(val => (
                    <MenuItem key={val} value={val}>{val}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}

            <TextField
              fullWidth
              label="הערות"
              multiline
              minRows={2}
              value={formData.notes ?? ''}
              onChange={e => handleChange('notes', e.target.value)}
              sx={{ mb: 2 }}
            />

            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              sx={{ fontWeight: 'bold' }}
            >
              שלח תשובה
            </Button>
          </CardContent>
        </Card>
      )}

      <Divider sx={{ mb: 2 }} />
      <Typography variant="subtitle1">📜 היסטוריית משימות</Typography>

      {pastTasks.map(task => (
        <Box key={task.id} sx={{ mt: 1, mb: 1, pl: 1 }}>
          <Typography variant="body2">
            ✅ {task.description} | תאריך: {task.date} | בוצע: {task.completed ? '✔️' : '❌'}
          </Typography>
        </Box>
      ))}
    </Box>
  );
};

export default TaskList;
