import { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  MenuItem,
  List,
  ListItem,
  ListItemText,
  Divider,
} from "@mui/material";
import axios from "axios";

const PatientView = ({ patient }) => {
  const today = new Date().toISOString().split("T")[0];
  const todayTask = patient.tasks.find((t) => t.date === today);

  const [completed, setCompleted] = useState(todayTask?.completed ?? false);
  const [reason, setReason] = useState(todayTask?.non_completion_reason || "");
  const [reaction, setReaction] = useState(todayTask?.reaction_level || "");
  const [notes, setNotes] = useState(todayTask?.notes || "");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    try {
      setSaving(true);
      await axios.patch(`/api/tasks/${todayTask.id}`, {
        completed,
        non_completion_reason: completed ? "" : reason,
        reaction_level: completed ? reaction : null,
        notes,
      });
      alert("המשוב נשלח בהצלחה ✅");
    } catch (err) {
      console.error("❌ Error saving task update:", err);
      alert("אירעה שגיאה בעת השמירה.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>
        🧒 {patient.name} – משימה ליום {today}
      </Typography>

      {todayTask ? (
        <Box>
          <Typography variant="body1" sx={{ mb: 1 }}>
            {todayTask.description}
          </Typography>

          <TextField
            select
            fullWidth
            label="האם בוצע?"
            value={completed ? "yes" : "no"}
            onChange={(e) => setCompleted(e.target.value === "yes")}
            sx={{ mb: 2 }}
          >
            <MenuItem value="yes">כן</MenuItem>
            <MenuItem value="no">לא</MenuItem>
          </TextField>

          {!completed && (
            <TextField
              select
              fullWidth
              label="סיבת אי-ביצוע"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              sx={{ mb: 2 }}
            >
              <MenuItem value="שכחתי">שכחתי</MenuItem>
              <MenuItem value="מחלה">מחלה</MenuItem>
              <MenuItem value="מחסור במוצר">מחסור במוצר</MenuItem>
              <MenuItem value="אחר">אחר</MenuItem>
            </TextField>
          )}

          {completed && (
            <TextField
              select
              fullWidth
              label="תגובה אלרגית (1-5)"
              value={reaction}
              onChange={(e) => setReaction(e.target.value)}
              sx={{ mb: 2 }}
            >
              {[1, 2, 3, 4, 5].map((num) => (
                <MenuItem key={num} value={num}>
                  {num}
                </MenuItem>
              ))}
            </TextField>
          )}

          <TextField
            fullWidth
            multiline
            rows={2}
            label="הערות"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            sx={{ mb: 2 }}
          />

          <Button variant="contained" onClick={handleSubmit} disabled={saving}>
            שלח משוב
          </Button>

          <Divider sx={{ my: 4 }} />
        </Box>
      ) : (
        <Typography variant="body2">אין משימה להיום.</Typography>
      )}

      <Typography variant="subtitle1" sx={{ mt: 2 }}>
        📋 היסטוריית משימות
      </Typography>
      <List>
        {patient.tasks.map((task) => (
          <ListItem key={task.id} divider>
            <ListItemText
              primary={task.description}
              secondary={`תאריך: ${task.date} | בוצע: ${task.completed ? "✅" : "❌"}`}
            />
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default PatientView;
