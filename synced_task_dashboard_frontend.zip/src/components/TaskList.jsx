
import React, { useState } from 'react';
import {
  Typography, Box, FormControl, Select, MenuItem, Button, TextField
} from '@mui/material';
import { patchTask } from '../utils/api';

const TaskList = ({ patient }) => {
  const [tasks, setTasks] = useState(patient.tasks || []);
  const [currentTask, ...pastTasks] = tasks;
  const [formData, setFormData] = useState({
    completed: currentTask?.completed ?? '',
    reason_not_completed: currentTask?.reason_not_completed || '',
    allergy_reaction: currentTask?.allergy_reaction || '',
    notes: currentTask?.notes || ''
  });
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const updated = await patchTask(currentTask.id, formData);
      const updatedTasks = [updated, ...pastTasks];
      setTasks(updatedTasks);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Box sx={{ p: 2 }}>
      <Typography fontWeight="bold" sx={{ mb: 1 }}>
        📝 מענה למשימה: {currentTask.description} לתאריך {currentTask.date}
      </Typography>
      <FormControl fullWidth sx={{ mb: 2 }}>
        <Typography>האם בוצע?</Typography>
        <Select value={formData.completed} name="completed" onChange={handleChange}>
          <MenuItem value={true}>כן</MenuItem>
          <MenuItem value={false}>לא</MenuItem>
        </Select>
      </FormControl>
      {formData.completed === false && (
        <FormControl fullWidth sx={{ mb: 2 }}>
          <Typography>סיבת אי-ביצוע</Typography>
          <Select value={formData.reason_not_completed} name="reason_not_completed" onChange={handleChange}>
            <MenuItem value="שכחתי">שכחתי</MenuItem>
            <MenuItem value="מחלה">מחלה</MenuItem>
            <MenuItem value="מחסור במוצר">מחסור במוצר</MenuItem>
            <MenuItem value="אחר">אחר</MenuItem>
          </Select>
        </FormControl>
      )}
      {formData.completed === true && (
        <FormControl fullWidth sx={{ mb: 2 }}>
          <Typography>דירוג תגובה אלרגית</Typography>
          <Select value={formData.allergy_reaction} name="allergy_reaction" onChange={handleChange}>
            {[1, 2, 3, 4, 5].map((n) => <MenuItem key={n} value={n}>{n}</MenuItem>)}
          </Select>
        </FormControl>
      )}
      <TextField
        fullWidth
        name="notes"
        label="הערות"
        value={formData.notes}
        onChange={handleChange}
        sx={{ mb: 2 }}
        multiline
        rows={2}
      />
      <Button variant="contained" onClick={handleSubmit} disabled={submitting}>
        שלח משוב
      </Button>

      <Box sx={{ mt: 4 }}>
        <Typography fontWeight="bold">📜 היסטוריית משימות</Typography>
        {pastTasks.map((t) => (
          <Box key={t.id}>
            <Typography variant="body2">{t.description} לתאריך {t.date}</Typography>
            <Typography variant="caption">בוצע: {t.completed ? '✅' : '❌'}</Typography>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default TaskList;
