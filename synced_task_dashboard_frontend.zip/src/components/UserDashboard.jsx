
import React, { useEffect, useState } from 'react';
import ParentView from './views/ParentView';
import PatientView from './views/PatientView';
import { getUserRole } from '../utils/api';

const UserDashboard = ({ user }) => {
  const [role, setRole] = useState(null);

  useEffect(() => {
    const fetchRole = async () => {
      if (!user?.email) return;
      try {
        const res = await getUserRole(user.email);
        setRole(res.role);
      } catch (err) {
        console.error("Error fetching role:", err);
      }
    };
    fetchRole();
  }, [user]);

  if (!role) return null;

  return (
    <>
      {role === 'parent' && <ParentView parentEmail={user.email} />}
      {role === 'patient' && <PatientView patient={user} />}
    </>
  );
};

export default UserDashboard;
