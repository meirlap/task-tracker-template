
import React, { useEffect, useState } from 'react';
import { Box, Typography, Card, CardContent, CircularProgress, Collapse } from '@mui/material';
import { ExpandMore } from '@mui/icons-material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import PatientView from './PatientView';
import { getChildrenAndTasks } from '../../utils/api';

const ParentView = ({ parentEmail }) => {
  const [children, setChildren] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    if (!parentEmail) return;
    const fetchChildren = async () => {
      try {
        const res = await getChildrenAndTasks(parentEmail);
        setChildren(res);
      } catch (err) {
        console.error('Error loading children:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchChildren();
  }, [parentEmail]);

  if (loading) return <CircularProgress sx={{ mt: 4 }} />;

  return (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>👪 בחר ילד</Typography>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {children.map((child) => (
          <Card key={child.id} variant="outlined" sx={{ width: '100%' }}>
            <CardContent onClick={() => setExpandedId(expandedId === child.id ? null : child.id)} sx={{ cursor: 'pointer' }}>
              <Typography variant="h6">{child.name}</Typography>
              <ExpandMoreIcon />
            </CardContent>
            <Collapse in={expandedId === child.id}>
              <PatientView patient={child} />
            </Collapse>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default ParentView;
