
import React from 'react';
import TaskList from '../TaskList';

const PatientView = ({ patient }) => {
  return <TaskList patient={patient} />;
};

export default PatientView;
